using UnityEngine;
using TMPro;

public class Delivery : MonoBehaviour
{
    bool hasPackage = false;
    ParticleSystem packageParticles;
    [SerializeField] TMP_Text scoreText;
    int score = 0;

    void Start()
    {
        packageParticles = GetComponent<ParticleSystem>();
        UpdateScoreUI();
    }

    void UpdateScoreUI()
    {
        scoreText.text = "Score: " + score;
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Package")&&!hasPackage)
        {
            hasPackage = true;
            packageParticles.Play();
            Destroy(collision.gameObject);
        }

        if (collision.CompareTag("Customer") && hasPackage)
        {
            Debug.Log("Delivered package!");
            hasPackage = false;
            packageParticles.Stop();
            score += 100;
            //UpdateScoreUI();
            Destroy(collision.gameObject);
        }
    }
}